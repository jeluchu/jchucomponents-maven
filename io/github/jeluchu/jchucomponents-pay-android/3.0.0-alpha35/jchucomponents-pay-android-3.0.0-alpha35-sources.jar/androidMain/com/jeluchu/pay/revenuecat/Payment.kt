package com.jeluchu.pay.revenuecat

import android.content.Context
import com.jeluchu.pay.revenuecat.extensions.empty
import com.jeluchu.jchucomponents.ktx.activities.findActivity
import com.jeluchu.pay.revenuecat.extensions.roundTo
import com.jeluchu.pay.revenuecat.models.BillingInfo
import com.jeluchu.pay.revenuecat.models.Product
import com.jeluchu.pay.revenuecat.models.SubscriptionInfo
import com.jeluchu.pay.revenuecat.models.SubscriptionState
import com.jeluchu.pay.revenuecat.models.SubscriptionsType
import com.revenuecat.purchases.CustomerInfo
import com.revenuecat.purchases.Package
import com.revenuecat.purchases.PackageType
import com.revenuecat.purchases.PurchaseParams
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.PurchasesError
import com.revenuecat.purchases.PurchasesErrorCode
import com.revenuecat.purchases.getOfferingsWith
import com.revenuecat.purchases.interfaces.PurchaseCallback
import com.revenuecat.purchases.interfaces.ReceiveCustomerInfoCallback
import com.revenuecat.purchases.models.StoreReplacementMode
import com.revenuecat.purchases.models.StoreTransaction
import com.revenuecat.purchases.models.googleProduct
import com.revenuecat.purchases.purchaseWith
import com.revenuecat.purchases.restorePurchasesWith
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 *
 * Author: @Jeluchu
 *
 * Init RevenueCat Configuration
 *
 */
class Payment {
    /**
     *
     * This variable stores the name of the subscription for which you want
     * to obtain the information, remember that it will be the same name
     * that you have declared in RevenueCat.
     *
     */
    var subscriptionName: String = String.empty()

    private fun getProducts(
        onSuccess: (BillingInfo) -> Unit,
        onFailure: (PurchasesError) -> Unit = {}
    ) = Purchases.sharedInstance.getOfferingsWith({ error -> onFailure(error) }) { offerings ->
        getCustomerInfo { customerInfo ->
            customerInfo?.let { info ->
                offerings.current?.availablePackages?.takeUnless { it.isEmpty() }?.let { packages ->
                    onSuccess(
                        BillingInfo(
                            info =
                                buildSubscriptionInfo(
                                    entitlement = subscriptionName,
                                    customerInfo = info,
                                    products = packages
                                ),
                            packages = packages,
                            products = buildSubscriptionProducts(packages)
                        )
                    )
                }
            }
        }
    }

    private fun buildSubscriptionProducts(products: List<Package>): List<Product> {
        val monthly = products.find { it.identifier == ProductsType.MONTHLY.type }
        val annual = products.find { it.identifier == ProductsType.ANNUAL.type }

        if (monthly != null && annual != null) {
            val annualPricePerMonth =
                (
                    annual.product.price.amountMicros
                        .toDouble() / 1000000
                ) / 12
            val pricePerMonth =
                monthly.product.price.amountMicros
                    .toDouble() / 1000000
            val savings = 100 - ((annualPricePerMonth / pricePerMonth) * 100)

            return listOf(
                Product(
                    isMonthly = true,
                    price = monthly.product.price.formatted,
                    priceConversion = null,
                    saveAmount = null,
                    storeProduct = monthly.product
                ),
                Product(
                    isMonthly = false,
                    price = annual.product.price.formatted,
                    priceConversion =
                        (
                            (
                                annual.product.price.amountMicros
                                    .toDouble() / 1000000
                            ) / 12
                        ).roundTo(2)
                            .toString(),
                    saveAmount = savings.roundToLong().toString(),
                    storeProduct = annual.product
                )
            )
        }

        return emptyList()
    }

    private fun buildSubscriptionInfo(
        entitlement: String,
        customerInfo: CustomerInfo,
        products: List<Package>
    ): SubscriptionInfo {
        val product =
            products.find { it.product.googleProduct?.productId == customerInfo.entitlements[entitlement]?.productIdentifier }
        var expire = "?"
        var isPromotional = false

        runCatching {
            expire =
                if (isSubscriptionExpired(customerInfo)) {
                    String.empty()
                } else {
                    SimpleDateFormat(
                        "dd/MM/yyyy HH:mm aaa",
                        Locale.ROOT
                    ).format(customerInfo.entitlements[entitlement]?.expirationDate ?: Date())
                }
        }

        return SubscriptionInfo(
            renewalType =
                when {
                    product?.identifier == ProductsType.MONTHLY.type -> SubscriptionsType.MONTHLY
                    product?.identifier == ProductsType.ANNUAL.type -> SubscriptionsType.YEARLY
                    PaymentProducts.promos.find { prom -> customerInfo.activeSubscriptions.find { it == prom } != null } != null -> {
                        isPromotional = true
                        SubscriptionsType.PROMO
                    }

                    else -> SubscriptionsType.NONE
                },
            promotional = isPromotional,
            expireDate = expire,
            state =
                if (isSubscriptionPaused(
                        entitlement,
                        customerInfo
                    )
                ) {
                    SubscriptionState.INACTIVE_UNTIL_RENEWAL
                } else {
                    SubscriptionState.ACTIVE
                },
            managementUrl = customerInfo.managementURL?.toString()
        )
    }

    private fun activateSubscription(
        customerInfo: CustomerInfo,
        onActiveSubscription: (Boolean, String) -> Unit
    ) = customerInfo.entitlements[subscriptionName]?.let { entitlementInfo ->
        if (entitlementInfo.isActive) {
            onActiveSubscription(
                true,
                entitlementInfo.productIdentifier
            )
        }
    }

    private fun isSubscriptionExpired(customerInfo: CustomerInfo): Boolean {
        val calendar = Calendar.getInstance()
        val currentTime = calendar.time
        calendar.time = customerInfo.requestDate

        val date: Date =
            if (currentTime.before(calendar.time)) customerInfo.requestDate else currentTime

        return customerInfo.entitlements[subscriptionName]?.expirationDate != null &&
            customerInfo.entitlements[subscriptionName]?.expirationDate?.after(date) == false
    }

    private fun subscriptionActive(customerInfo: CustomerInfo): Boolean =
        customerInfo.entitlements[subscriptionName]?.isActive == true &&
            !isSubscriptionExpired(
                customerInfo
            )

    private fun isSubscriptionPaused(
        entitlement: String,
        customerInfo: CustomerInfo
    ) = !subscriptionActive(customerInfo) && customerInfo.entitlements[entitlement]?.willRenew == true

    private fun getCustomerInfo(callback: (CustomerInfo?) -> Unit) {
        Purchases.sharedInstance.getCustomerInfo(
            object : ReceiveCustomerInfoCallback {
                override fun onError(error: PurchasesError) = callback.invoke(null)

                override fun onReceived(customerInfo: CustomerInfo) = callback.invoke(customerInfo)
            }
        )
    }

    /**
     *
     * Currently two types of subscriptions are supported, those that are
     * [ProductsType.ANNUAL] and those that are [ProductsType.MONTHLY], for
     * which you can easily use this enum, which is already used in some
     * of the [Payment] functions to obtain the necessary information.
     *
     */
    enum class ProductsType(
        val type: String,
        val packageType: PackageType
    ) {
        ANNUAL(type = "\$rc_annual", PackageType.ANNUAL),
        MONTHLY(type = "\$rc_monthly", PackageType.MONTHLY)
    }

    companion object {
        private val payment = Payment()
        val userId: String = Purchases.sharedInstance.appUserID

        val billingError: StateFlow<PurchasesError>
            field = MutableStateFlow(PurchasesError(PurchasesErrorCode.UnknownError))

        val billingInfo: StateFlow<BillingInfo>
            field = MutableStateFlow(BillingInfo.empty())

        fun setSubscriptionName(name: String) {
            payment.subscriptionName = name
        }

        /**
         *
         * This function will be used to obtain all available
         * products declared in RevenueCat. It is important
         * that you have initialized the configuration from
         * the function: Context.initPayment in your Application class.
         *
         * @see <a href="https://www.revenuecat.com/docs/getting-started/displaying-products">Displaying products</a>
         *
         */
        fun getProducts() =
            payment.getProducts(
                onSuccess = { billingInfo.value = it },
                onFailure = { billingError.value = it }
            )

        /**
         * Loads the current RevenueCat offering and the user's subscription
         * information as a suspendable operation.
         *
         * This keeps platform adapters from having to coordinate the legacy
         * callback API with their own coroutine state.
         */
        suspend fun loadBillingInfo(): BillingInfo = suspendCancellableCoroutine { continuation ->
            payment.getProducts(
                onSuccess = { info ->
                    billingInfo.value = info
                    if (continuation.isActive) continuation.resume(info)
                },
                onFailure = { error ->
                    billingError.value = error
                    if (continuation.isActive) {
                        continuation.resumeWithException(IllegalStateException(error.message))
                    }
                }
            )
        }

        /**
         * Purchases a monthly or annual package using the configured
         * RevenueCat offering.
         */
        suspend fun purchaseResult(
            context: Context,
            type: ProductsType
        ): Pair<Boolean, String> = suspendCancellableCoroutine { continuation ->
            purchase(
                context = context,
                type = type,
                onSuccess = { active, productIdentifier ->
                    if (continuation.isActive) continuation.resume(active to productIdentifier)
                },
                onFailure = { error, userCancelled ->
                    if (continuation.isActive) {
                        val message = if (userCancelled) {
                            "Purchase cancelled"
                        } else {
                            error.message
                        }
                        continuation.resumeWithException(IllegalStateException(message))
                    }
                }
            )
        }

        /**
         * Restores the purchases associated with the current store account.
         */
        suspend fun restorePurchasesResult(): Pair<Boolean, String> =
            suspendCancellableCoroutine { continuation ->
                restorePurchases { active, productIdentifier ->
                    if (continuation.isActive) continuation.resume(active to productIdentifier)
                }
            }

        /**
         *
         * This function is used to make a purchase request for our
         * products/subscriptions. Remember that in addition to having
         * the products/offers declared in RevenueCat, you must also
         * have them included in the Store.
         *
         * @param context [Context]
         * @param type [ProductsType] the type of product we want to obtain,
         * either on an annual or monthly basis
         * @param onSuccess [Unit] if the answer is correct, a boolean
         * with the subscription status and the id of the corresponding
         * product will be returned in the unit.
         * @param onFailure [Unit] in case the answer is wrong, a PurchaseError
         * with information about the problem and a boolean with the subscription
         * status will be returned in the unit.
         *
         * @see <a href="https://www.revenuecat.com/docs/getting-started/making-purchases">Making purchases</a>
         *
         */
        fun purchase(
            context: Context,
            type: ProductsType,
            onSuccess: (Boolean, String) -> Unit = { _, _ -> },
            onFailure: (PurchasesError, Boolean) -> Unit = { _, _ -> }
        ) = context.findActivity()?.let { activity ->
            billingInfo.value.packages.apply {
                if (isNotEmpty()) {
                    Purchases.sharedInstance.purchaseWith(
                        PurchaseParams.Builder(activity, first { it.packageType == type.packageType }).build(),
                        onError = { error, userCancelled -> onFailure(error, userCancelled) },
                        onSuccess = { _, customerInfo -> payment.activateSubscription(customerInfo, onSuccess) }
                    )
                }
            }
        }

        /**
         *
         * If a person is already a subscriber, you can upgrade
         * the subscription status from Annual to Monthly, or from Monthly to Annual.
         * However, cancellations can only be made through the Store.
         *
         * @param context [Context]
         * @param onSuccess [Unit] if the answer is correct, a boolean
         * with the subscription status and the id of the corresponding
         * product will be returned in the unit.
         * @param onFailure [Unit] in case the answer is wrong, a PurchaseError
         * with information about the problem and a boolean with the subscription
         * status will be returned in the unit.
         *
         */
        fun upgradeDownGrade(
            context: Context,
            onSuccess: (Boolean, String) -> Unit = { _, _ -> },
            onFailure: (PurchasesError, Boolean) -> Unit = { _, _ -> }
        ) = payment.getCustomerInfo { info ->
            if (info != null) {
                if (billingInfo.value.packages.isNotEmpty()) {
                    val monthlyProduct =
                        billingInfo.value.packages.find { it.packageType == PackageType.MONTHLY }
                    val annualProduct =
                        billingInfo.value.packages.find { it.packageType == PackageType.ANNUAL }

                    info.entitlements[payment.subscriptionName]?.let { entitlementInfo ->
                        when {
                            entitlementInfo.isActive &&
                                entitlementInfo.productIdentifier == monthlyProduct?.product?.googleProduct?.productId -> {
                                context.findActivity()?.let { activity ->
                                    annualProduct?.let { product ->
                                        Purchases.sharedInstance.purchase(
                                            PurchaseParams
                                                .Builder(activity, product)
                                                .oldProductId(
                                                    monthlyProduct.product.googleProduct
                                                        ?.productId
                                                        .orEmpty()
                                                ).replacementMode(StoreReplacementMode.WITHOUT_PRORATION)
                                                .build(),
                                            object : PurchaseCallback {
                                                override fun onCompleted(
                                                    storeTransaction: StoreTransaction,
                                                    customerInfo: CustomerInfo
                                                ) {
                                                    payment.activateSubscription(customerInfo, onSuccess)
                                                }

                                                override fun onError(
                                                    error: PurchasesError,
                                                    userCancelled: Boolean
                                                ) = onFailure(error, userCancelled)
                                            }
                                        )
                                    }
                                }
                            }

                            entitlementInfo.isActive &&
                                entitlementInfo.productIdentifier == annualProduct?.product?.googleProduct?.productId -> {
                                context.findActivity()?.let { activity ->
                                    monthlyProduct?.let { product ->
                                        Purchases.sharedInstance.purchase(
                                            PurchaseParams
                                                .Builder(activity, product)
                                                .oldProductId(
                                                    annualProduct.product.googleProduct
                                                        ?.productId
                                                        .orEmpty()
                                                ).replacementMode(StoreReplacementMode.WITHOUT_PRORATION)
                                                .build(),
                                            object : PurchaseCallback {
                                                override fun onCompleted(
                                                    storeTransaction: StoreTransaction,
                                                    customerInfo: CustomerInfo
                                                ) {
                                                    payment.activateSubscription(customerInfo, onSuccess)
                                                }

                                                override fun onError(
                                                    error: PurchasesError,
                                                    userCancelled: Boolean
                                                ) = onFailure(error, userCancelled)
                                            }
                                        )
                                    }
                                }
                            }

                            else -> {}
                        }
                    }
                } else {
                    onFailure(PurchasesError(PurchasesErrorCode.NetworkError), false)
                }
            } else {
                onFailure(PurchasesError(PurchasesErrorCode.NetworkError), false)
            }
        }

        /**
         *
         * Restoring purchases is a mechanism by which your user
         * can restore their in-app purchases, reactivating any
         * content that had previously been purchased from the
         * same store account
         *
         * @param onRestored [Unit] if the answer is correct, a boolean
         * with the subscription status and the id of the corresponding
         * product will be returned in the unit.
         *
         * @see <a href="https://www.revenuecat.com/docs/getting-started/restoring-purchases">Restoring purchases</a>
         *
         */
        fun restorePurchases(onRestored: (Boolean, String) -> Unit = { _, _ -> }) =
            Purchases.sharedInstance.restorePurchasesWith { customerInfo ->
                customerInfo.let { info ->
                    info.entitlements[payment.subscriptionName]?.let { entitlementInfo ->
                        if (entitlementInfo.isActive) {
                            onRestored(true, entitlementInfo.productIdentifier)
                        } else {
                            onRestored(false, String.empty())
                        }
                    }
                }
            }

        /**
         *
         * Checks whether the user is subscribed or not.
         *
         * @param onChecked [Unit] if the answer is correct, a boolean
         * with the subscription status and the id of the corresponding
         * product will be returned in the unit.
         *
         */
        fun isSubscriptionActive(onChecked: (Boolean, String) -> Unit = { _, _ -> }) =
            payment.getCustomerInfo { customerInfo ->
                customerInfo?.let { info ->
                    info.entitlements[payment.subscriptionName]?.let { entitlementInfo ->
                        if (entitlementInfo.isActive && payment.subscriptionActive(customerInfo)) {
                            onChecked(true, entitlementInfo.productIdentifier)
                        } else {
                            onChecked(false, String.empty())
                        }
                    }
                }
            }
    }

    object PaymentProducts {
        val promos =
            listOf(
                "rc_promo_pro_daily",
                "rc_promo_pro_three_day",
                "rc_promo_pro_weekly",
                "rc_promo_pro_monthly",
                "rc_promo_pro_three_month",
                "rc_promo_pro_six_month",
                "rc_promo_pro_yearly",
                "rc_promo_pro_lifetime"
            )
    }
}
