/*
 *
 *  Copyright 2022 Jeluchu
 *
 */

package com.jeluchu.jchucomponents.ktx.constants

const val INTENT_TYPE_EMAIL = "message/rfc822"
const val INTENT_TYPE_TEXT = "text/plain"
const val INTENT_TYPE_JSON = "application/json"
const val INTENT_TYPE_TEXT_HTML = "text/html"
const val INTENT_TYPE_IMG_JPG = "image/jpg"
const val INTENT_TYPE_IMG_PNG = "image/png"

@Suppress("ktlint:standard:property-naming")
const val INTENT_TYPE_IMGs = "image/*"
const val INTENT_TYPE_APK = "application/vnd.android.package-archive"
const val INTENT_TYPE_PDF = "application/pdf"
const val INTENT_TYPE_VIDEO = "video/*"
const val INTENT_TYPE_DOCUMENT = "*/*"
