@file:OptIn(InternalResourceApi::class)

package com.jeluchu.jchucomponents.pdf.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.jeluchu.jchucomponents.pdf.resources/"

@delegate:ResourceContentHash(2_093_954_297)
internal val Res.string.jchu_pdf_back: StringResource by lazy {
      StringResource("string:jchu_pdf_back", "jchu_pdf_back", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 10, 29),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 29),
      ))
    }

@delegate:ResourceContentHash(-1_548_603_038)
internal val Res.string.jchu_pdf_desktop_hint: StringResource by lazy {
      StringResource("string:jchu_pdf_desktop_hint", "jchu_pdf_desktop_hint", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 40, 109),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 40, 89),
      ))
    }

@delegate:ResourceContentHash(-424_063_673)
internal val Res.string.jchu_pdf_desktop_open: StringResource by lazy {
      StringResource("string:jchu_pdf_desktop_open", "jchu_pdf_desktop_open", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 150, 41),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 130, 41),
      ))
    }

@delegate:ResourceContentHash(178_449_310)
internal val Res.string.jchu_pdf_error: StringResource by lazy {
      StringResource("string:jchu_pdf_error", "jchu_pdf_error", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 271, 70),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 243, 62),
      ))
    }

@delegate:ResourceContentHash(-458_462_622)
internal val Res.string.jchu_pdf_error_unknown: StringResource by lazy {
      StringResource("string:jchu_pdf_error_unknown", "jchu_pdf_error_unknown", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 192, 78),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 172, 70),
      ))
    }

@delegate:ResourceContentHash(1_912_183_882)
internal val Res.string.jchu_pdf_next_page: StringResource by lazy {
      StringResource("string:jchu_pdf_next_page", "jchu_pdf_next_page", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 342, 50),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 306, 38),
      ))
    }

@delegate:ResourceContentHash(-812_925_465)
internal val Res.string.jchu_pdf_page_description: StringResource by lazy {
      StringResource("string:jchu_pdf_page_description", "jchu_pdf_page_description", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 393, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 345, 45),
      ))
    }

@delegate:ResourceContentHash(-1_530_475_174)
internal val Res.string.jchu_pdf_page_indicator: StringResource by lazy {
      StringResource("string:jchu_pdf_page_indicator", "jchu_pdf_page_indicator", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 443, 47),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 391, 47),
      ))
    }

@delegate:ResourceContentHash(-2_057_390_807)
internal val Res.string.jchu_pdf_previous_page: StringResource by lazy {
      StringResource("string:jchu_pdf_previous_page", "jchu_pdf_previous_page", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 491, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 439, 50),
      ))
    }

@delegate:ResourceContentHash(-668_521_199)
internal val Res.string.jchu_pdf_retry: StringResource by lazy {
      StringResource("string:jchu_pdf_retry", "jchu_pdf_retry", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 546, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 490, 30),
      ))
    }

@delegate:ResourceContentHash(204_119_659)
internal val Res.string.jchu_pdf_rotate_left: StringResource by lazy {
      StringResource("string:jchu_pdf_rotate_left", "jchu_pdf_rotate_left", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 585, 56),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 521, 44),
      ))
    }

@delegate:ResourceContentHash(-1_714_738_404)
internal val Res.string.jchu_pdf_rotate_right: StringResource by lazy {
      StringResource("string:jchu_pdf_rotate_right", "jchu_pdf_rotate_right", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 642, 53),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 566, 45),
      ))
    }

@delegate:ResourceContentHash(-221_172_026)
internal val Res.string.jchu_pdf_share: StringResource by lazy {
      StringResource("string:jchu_pdf_share", "jchu_pdf_share", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 816, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 712, 34),
      ))
    }

@delegate:ResourceContentHash(-1_203_060_605)
internal val Res.string.jchu_pdf_share_dismiss: StringResource by lazy {
      StringResource("string:jchu_pdf_share_dismiss", "jchu_pdf_share_dismiss", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 696, 42),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 612, 34),
      ))
    }

@delegate:ResourceContentHash(-1_214_343_394)
internal val Res.string.jchu_pdf_share_error: StringResource by lazy {
      StringResource("string:jchu_pdf_share_error", "jchu_pdf_share_error", setOf(
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 739, 76),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 647, 64),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("jchu_pdf_back", Res.string.jchu_pdf_back)
  map.put("jchu_pdf_desktop_hint", Res.string.jchu_pdf_desktop_hint)
  map.put("jchu_pdf_desktop_open", Res.string.jchu_pdf_desktop_open)
  map.put("jchu_pdf_error", Res.string.jchu_pdf_error)
  map.put("jchu_pdf_error_unknown", Res.string.jchu_pdf_error_unknown)
  map.put("jchu_pdf_next_page", Res.string.jchu_pdf_next_page)
  map.put("jchu_pdf_page_description", Res.string.jchu_pdf_page_description)
  map.put("jchu_pdf_page_indicator", Res.string.jchu_pdf_page_indicator)
  map.put("jchu_pdf_previous_page", Res.string.jchu_pdf_previous_page)
  map.put("jchu_pdf_retry", Res.string.jchu_pdf_retry)
  map.put("jchu_pdf_rotate_left", Res.string.jchu_pdf_rotate_left)
  map.put("jchu_pdf_rotate_right", Res.string.jchu_pdf_rotate_right)
  map.put("jchu_pdf_share", Res.string.jchu_pdf_share)
  map.put("jchu_pdf_share_dismiss", Res.string.jchu_pdf_share_dismiss)
  map.put("jchu_pdf_share_error", Res.string.jchu_pdf_share_error)
}
