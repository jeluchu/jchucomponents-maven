package com.jeluchu.jchucomponents.pdf.navigation

import androidx.navigation3.runtime.NavKey
import kotlinx.serialization.Serializable

@Serializable
sealed interface PdfReaderKmpRoutes : NavKey {
    @Serializable
    data class Reader(
        val url: String,
    ) : PdfReaderKmpRoutes
}
