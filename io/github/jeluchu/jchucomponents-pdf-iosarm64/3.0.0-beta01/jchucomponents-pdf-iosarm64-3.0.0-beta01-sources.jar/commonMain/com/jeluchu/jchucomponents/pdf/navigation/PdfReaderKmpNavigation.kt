package com.jeluchu.jchucomponents.pdf.navigation

import androidx.navigation3.runtime.EntryProviderScope
import androidx.navigation3.runtime.NavBackStack
import androidx.navigation3.runtime.NavKey
import com.jeluchu.jchucomponents.navigation3.extensions.back
import com.jeluchu.jchucomponents.pdf.JchuPdfReaderScreen

fun EntryProviderScope<NavKey>.pdfReaderKmpEntries(
    backStack: NavBackStack<NavKey>,
) {
    entry<PdfReaderKmpRoutes.Reader> { key ->
        JchuPdfReaderScreen(
            url = key.url,
            onBack = { backStack.back() },
        )
    }
}
